class GrammarError(Exception):
    """Raised when a query has invalid grammar."""
    pass
